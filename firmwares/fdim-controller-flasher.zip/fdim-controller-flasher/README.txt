# FDIM Controller easy (well, relatively...) flasher for Windows

Firmware included: version from 2019.12.24

1. Install drivers from drivers1 folder (dpinst.exe for your platform)
2. Install drivers from drivers2 folder (dpinst.exe for your platform)
3. Plug-in FDIM Controller
4. Wait till Spark Fun Pro Micro (COMn) device appears under Serial Ports in Device Manager
5. Run upload.bat
6. Observe Arduino Leonardo bootloader device appear under Serial Ports in Device Manager for a few seconds and ensure 
   that driver is installing. If not - point to drivers1 folder
7. Re-run upload.bat and wait for Reading and Writing progress bars to complete

